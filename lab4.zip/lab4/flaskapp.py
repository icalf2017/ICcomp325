import os
from datetime import datetime

from flask import Flask, render_template, session, redirect, url_for, flash, request, g
from flask_script import Manager, Shell
from flask_bootstrap import Bootstrap
from flask_moment import Moment
from flask_wtf import Form
from wtforms import StringField, SubmitField, TextAreaField, SelectField, SelectMultipleField
from wtforms.validators import Required
from flask_sqlalchemy import SQLAlchemy

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SECRET_KEY'] = 'comp205'
app.config['SQLALCHEMY_DATABASE_URI'] =\
    'sqlite:///' + os.path.join(basedir, 'datalab4.sqlite')
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

manager = Manager(app)
bootstrap = Bootstrap(app)
moment = Moment(app)
db = SQLAlchemy(app)


class Genre(db.Model):
    __tablename__ = 'genres'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)
    artists = db.relationship('Artist', backref='genre')

    def __repr__(self):
        return '<Genre %r>' % self.genre_name


class Artist(db.Model):
    __tablename__ = 'artists'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, index=True)
    genre_id = db.Column(db.Integer, db.ForeignKey('genres.id'))
    desc = db.Column(db.String(256), unique=True, index=True)

    def __repr__(self):
        return '<Artist %r>' % self.artist


class NewGenre(Form):
    newgenre = StringField('New Genre', validators=[Required()])
    submit = SubmitField('Submit')

class NameForm(Form):
    name = StringField('New Artist Name', validators=[Required()])
    genre = SelectField('Genre', coerce=int, validators=[Required()])
    description = TextAreaField('Description')
    submit = SubmitField('Submit')

# def make_shell_context():
#     return dict(app=app, db=db, Genre=Genre, Artist=Artist)
# manager.add_command("shell", Shell(make_context=make_shell_context))

def createDB():
    db.drop_all()
    db.create_all()
    genres_arock = Genre(name='Alternative Rock')
    genres_america = Genre(name='Americana')
    genres_prock = Genre(name='Pop Rock')
    db.session.add(genres_arock)
    db.session.add(genres_america)
    db.session.add(genres_prock)
    artist_coldplay = Artist(name='Coldplay', genre=genres_arock,desc='British rock band formed in 1996')
    artist_lumineers = Artist(name='The Lumineers', genre=genres_america, desc='Folk rock band based in Denver, CO')
    artist_script = Artist(name='The Script', genre=genres_prock, desc='Irish pop rock band formed in 2001')
    db.session.add(artist_coldplay)
    db.session.add(artist_lumineers)
    db.session.add(artist_script)
    # db.session.add_all(artist_coldplay, artist_lumineers, artist_script)
    db.session.commit()

createDB()

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

@app.route('/')
def index():
    return render_template('index.html',
                           current_time=datetime.utcnow())

@app.route('/listartists')
def listartists():
    filter = Artist.query.all()
    filter = [user.name for user in filter]
    return render_template('listsartists.html', alist=filter)

@app.route('/specific/<aname>')
def specific(aname):
    info = Artist.query.filter_by(name=aname).first()
    if info is not None:
        return render_template('specific.html', artist=aname, genre=info.genre.name, description=info.desc)
    else:
        return render_template('404.html'), 404



@app.route('/newg', methods=['GET', 'POST'])
def newg():
    myForm = NewGenre()
    if myForm.validate_on_submit():
        brandNewGenre = Genre(name = myForm.newgenre.data)
        db.session.add(brandNewGenre)
        flash('This genre has been added to the database!')
        return redirect(url_for('new'))
    return render_template('newg.html', thisForm = myForm)

@app.route('/new', methods=['GET', 'POST'])
def new():
    filter = Artist.query.all()
    filter = [user.name for user in filter]
    form = NameForm()
    form.genre.choices = [(g.id, g.name) for g in Genre.query.all()]
    if form.validate_on_submit():
        brandNewArtist = Artist(name = form.name.data, genre_id = form.genre.data, desc = form.description.data)
        db.session.add(brandNewArtist)
        flash('Your input has been added to the Artist List!')
        return redirect(url_for('listartists'))
    return render_template('new.html', form=form)

if __name__ == '__main__':

    app.run()

    # app.run when uploading
    # manager.run when editing






